from django.shortcuts import render
from .models import page
from django.http import HttpResponse

# Create your views here.
def index(request):
    return render(request, 'blog/index.html')
def about(request):
    return render(request, 'blog/about.html')
def contact(request):
    return render(request, 'blog/contact.html')
def video(request):
    total_page = page.objects.all()
    print(total_page)
    n=len(total_page)
    print(n)
    params={'range': range(-n), 't_blog':total_page}
    return render(request, 'blog/video.html',params)
