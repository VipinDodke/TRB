from django.contrib import admin
from .models import page
# Register your models here.
admin.site.register(page)