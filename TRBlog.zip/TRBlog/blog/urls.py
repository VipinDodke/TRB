from django.urls import path
from . import views
urlpatterns = [
    path('',views.index,name="BlogHOme" ),
    path('about/',views.about,name="AboutUS" ),
    path('contact/',views.contact,name="Contact" ),
    path('video/',views.video,name="Video" ),
]
